# Databricks notebook source
path = "/Volumes/population_metrics/landing/datasets/countries_dataset/countries_dataset/csv_data/countries_population/countries_population.csv"

# COMMAND ----------

df = spark.read.csv(path=path, header=True)

df.display()

# COMMAND ----------

df = spark.read.load(path, format="csv", header=True)

df.display()

# COMMAND ----------

df = spark.read.format("csv").load("/Volumes/population_metrics/landing/datasets/countries_dataset/countries_dataset/csv_data/countries_population_partitioned/")

df.display()