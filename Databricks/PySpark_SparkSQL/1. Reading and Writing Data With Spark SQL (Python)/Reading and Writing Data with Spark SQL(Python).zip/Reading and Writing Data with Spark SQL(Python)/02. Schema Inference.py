# Databricks notebook source
path = "/Volumes/population_metrics/landing/datasets/countries_dataset/countries_dataset/csv_data/countries_population/countries_population.csv"

# COMMAND ----------

df = spark.read.format("csv").options(header=True).load(path)

# COMMAND ----------

df.dtypes

# COMMAND ----------

df.describe()

# COMMAND ----------

df.printSchema()

# COMMAND ----------

df = spark.read.format("csv").options(header = True, inferSchema = True).load(path)

df.display()