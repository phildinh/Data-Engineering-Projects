# Databricks notebook source
path = "/Volumes/population_metrics/landing/datasets/countries_dataset/countries_dataset/csv_data/countries_population/countries_population.csv"

# COMMAND ----------

from pyspark.sql.types import StructType, StructField, StringType, IntegerType

schema = StructType(
        [
                StructField("country_id", IntegerType(), False),
                StructField("name", StringType(), True),
                StructField("nationality", StringType(), True),
                StructField("country_code", StringType(), True),
                StructField("iso_alpha2", StringType(), True),
                StructField("capital", StringType(), True),
                StructField("population", IntegerType(), True),
                StructField("area_km2", IntegerType(), True),
                StructField("region_id", IntegerType(), True),
                StructField("sub_region_id", IntegerType(), True)
        ]
)

# COMMAND ----------

df = spark.read.format("csv")\
                .options(header=True)\
                .schema(schema)\
                .load(path)

# COMMAND ----------

output_path = "/Volumes/population_metrics/landing/datasets/output_dataset/csv/countries_population"

# COMMAND ----------

df.write.mode("overwrite").options(header=True).csv(output_path)

# COMMAND ----------

df.write.format("csv").mode("overwrite").options(header=True).save(output_path)