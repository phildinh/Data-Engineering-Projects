# Databricks notebook source
dbutils.help()

# COMMAND ----------

dbutils.fs.help()

# COMMAND ----------

help(dbutils.fs.cp)

# COMMAND ----------

dbutils.fs.cp("/Volumes/population_metrics/landing/datasets/output_dataset/csv/countries_population/part-00000-tid-1471461417202667201-8f719706-e3ff-4acb-bc17-7019f0a8c549-23-1-c000.csv",
              "/Volumes/population_metrics/landing/datasets/output_dataset")

# COMMAND ----------

dbutils.fs.cp("/Volumes/population_metrics/landing/datasets/output_dataset/csv/countries_population/",
              "/Volumes/population_metrics/landing/datasets/output_dataset/countries_population_copies",
              recurse=True)

# COMMAND ----------

help(dbutils.fs.mkdirs)

# COMMAND ----------

dbutils.fs.mkdirs("/Volumes/population_metrics/landing/datasets/output_dataset/practice")

# COMMAND ----------

help(dbutils.fs.rm)

# COMMAND ----------

dbutils.fs.rm("/Volumes/population_metrics/landing/datasets/output_dataset/part-00000-tid-1471461417202667201-8f719706-e3ff-4acb-bc17-7019f0a8c549-23-1-c000.csv")

# COMMAND ----------

dbutils.fs.rm("/Volumes/population_metrics/landing/datasets/output_dataset/countries_population_copies/", recurse=True)

# COMMAND ----------

help(dbutils.fs.ls)

# COMMAND ----------

display(dbutils.fs.ls("dbfs:/Volumes/population_metrics/landing/datasets/output_dataset/csv/countries_population/"))