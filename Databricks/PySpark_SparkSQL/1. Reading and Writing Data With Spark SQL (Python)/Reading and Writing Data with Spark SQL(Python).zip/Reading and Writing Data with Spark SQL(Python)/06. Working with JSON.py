# Databricks notebook source
from pyspark.sql.types import StructType, StructField, StringType, IntegerType

schema = StructType(
        [
                StructField("country_id", IntegerType(), False),
                StructField("name", StringType(), True),
                StructField("nationality", StringType(), True),
                StructField("country_code", StringType(), True),
                StructField("iso_alpha2", StringType(), True),
                StructField("capital", StringType(), True),
                StructField("population", IntegerType(), True),
                StructField("area_km2", IntegerType(), True),
                StructField("region_id", IntegerType(), True),
                StructField("sub_region_id", IntegerType(), True)
        ]
)

path = "/Volumes/population_metrics/landing/datasets/countries_dataset/countries_dataset/csv_data/countries_population/countries_population.csv"

df = spark.read.format("csv").schema(schema).options(header=True).load(path)

# COMMAND ----------

df.write.format("json").mode("overwrite").save("/Volumes/population_metrics/landing/datasets/output_dataset/json/countries_population")

# COMMAND ----------

spark.read.format("json").load("/Volumes/population_metrics/landing/datasets/output_dataset/json/countries_population").display()

# COMMAND ----------

from pyspark.sql.types import StructType, StructField, StringType, IntegerType

schema = StructType(
        [
                StructField("country_id", IntegerType(), False),
                StructField("name", StringType(), True),
                StructField("nationality", StringType(), True),
                StructField("country_code", StringType(), True),
                StructField("iso_alpha2", StringType(), True),
                StructField("capital", StringType(), True),
                StructField("population", IntegerType(), True),
                StructField("area_km2", IntegerType(), True),
                StructField("region_id", IntegerType(), True),
                StructField("sub_region_id", IntegerType(), True)
        ]
)

path = "/Volumes/population_metrics/landing/datasets/output_dataset/json/countries_population"

df = spark.read.format("json").schema(schema).load(path)

df.display()