# Databricks notebook source
path = "/Volumes/population_metrics/landing/datasets/countries_dataset/countries_dataset/csv_data/countries_population/countries_population.csv"

# COMMAND ----------

schema = """
        COUNTRY_ID int, 
        NAME string, 
        NATIONALITY string, 
        COUNTRY_CODE string, 
        ISO_ALPHA2 string, 
        CAPITAL string, 
        POPULATION int, 
        AREA_KM2 int, 
        REGION_ID int, 
        SUB_REGION_ID int
        """

# COMMAND ----------

df = spark.read.format("csv")\
                .options(header=True)\
                .schema(schema)\
                .load(path)

# COMMAND ----------

