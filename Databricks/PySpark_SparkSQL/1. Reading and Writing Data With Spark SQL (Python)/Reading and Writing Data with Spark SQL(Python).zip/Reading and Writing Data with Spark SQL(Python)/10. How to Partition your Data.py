# Databricks notebook source
from pyspark.sql.types import StructType, StructField, StringType, IntegerType

schema = StructType(
        [
                StructField("country_id", IntegerType(), False),
                StructField("name", StringType(), True),
                StructField("nationality", StringType(), True),
                StructField("country_code", StringType(), True),
                StructField("iso_alpha2", StringType(), True),
                StructField("capital", StringType(), True),
                StructField("population", IntegerType(), True),
                StructField("area_km2", IntegerType(), True),
                StructField("region_id", IntegerType(), True),
                StructField("sub_region_id", IntegerType(), True)
        ]
)

path = "/Volumes/population_metrics/landing/datasets/countries_dataset/countries_dataset/csv_data/countries_population/countries_population.csv"

df = spark.read.format("csv").schema(schema).options(header=True).load(path)

df.display()

# COMMAND ----------

df.write.format("csv")\
        .partitionBy("region_id","sub_region_id")\
        .mode("overwrite")\
        .save("/Volumes/population_metrics/landing/datasets/output_dataset/csv/countries_population_partitioned")

# COMMAND ----------

df = spark.read.format("delta").load("/Volumes/population_metrics/landing/datasets/output_dataset/delta_lake/countries_population")